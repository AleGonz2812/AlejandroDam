using System;
using IncomeExpenseManager.Models;
using IncomeExpenseManager.Utils;
using System.Linq;

namespace IncomeExpenseManager
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Introduce tu nombre: ");
            string nombre = Console.ReadLine();

            Console.Write("Introduce tu edad: ");
            int edad;
            while (!int.TryParse(Console.ReadLine(), out edad))
            {
                Console.Write("Edad no válida. Introduce tu edad: ");
            }

            string dni;
            while (true)
            {
                Console.Write("Introduce tu DNI: ");
                dni = Console.ReadLine();
                if (DniValidator.ValidateDni(dni))
                {
                    break;
                }
                Console.WriteLine("DNI no válido. Inténtalo de nuevo.");
            }

            Usuario user = new Usuario(nombre, edad);
            user.SetDni(dni);

            Cuenta cuenta = new Cuenta(user);
            Wishlist wishlist = new Wishlist(user);

            while (true)
            {
                Console.WriteLine("\nRealiza una nueva acción");
                Console.WriteLine("1 Introduce un nuevo gasto básico");
                Console.WriteLine("2 Introduce un nuevo gasto extra");
                Console.WriteLine("3 Introduce un nuevo ingreso");
                Console.WriteLine("4 Mostrar gastos");
                Console.WriteLine("5 Mostrar ingresos");
                Console.WriteLine("6 Mostrar saldo");
                Console.WriteLine("7 Mostrar ahorro de un período");
                Console.WriteLine("8 Mostrar gastos imprescindibles");
                Console.WriteLine("9 Mostrar posibles ahorros del mes pasado");
                Console.WriteLine("10 Mostrar lista de deseos");
                Console.WriteLine("11 Mostrar productos que podemos comprar");
                Console.WriteLine("0 Salir");
                Console.Write("Selecciona una opción: ");
                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        Console.Write("Introduce la cantidad del gasto básico: ");
                        decimal cantidadBasico;
                        while (!decimal.TryParse(Console.ReadLine(), out cantidadBasico))
                        {
                            Console.Write("Cantidad no válida. Introduce la cantidad del gasto básico: ");
                        }
                        Console.Write("Introduce una descripción: ");
                        string descripcionBasico = Console.ReadLine();
                        try
                        {
                            cuenta.AddGastoBasico(cantidadBasico, descripcionBasico);
                            Console.WriteLine("Gasto básico añadido.");
                        }
                        catch (InvalidOperationException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;

                    case "2":
                        Console.Write("Introduce la cantidad del gasto extra: ");
                        decimal cantidadExtra;
                        while (!decimal.TryParse(Console.ReadLine(), out cantidadExtra))
                        {
                            Console.Write("Cantidad no válida. Introduce la cantidad del gasto extra: ");
                        }
                        Console.Write("Introduce una descripción: ");
                        string descripcionExtra = Console.ReadLine();
                        Console.Write("¿Es prescindible? (s/n): ");
                        bool prescindible = Console.ReadLine().Trim().ToLower() == "s";
                        try
                        {
                            cuenta.AddGastoExtra(cantidadExtra, descripcionExtra, prescindible);
                            Console.WriteLine("Gasto extra añadido.");
                        }
                        catch (InvalidOperationException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;

                    case "3":
                        Console.Write("Introduce la cantidad del ingreso: ");
                        decimal cantidadIngreso;
                        while (!decimal.TryParse(Console.ReadLine(), out cantidadIngreso))
                        {
                            Console.Write("Cantidad no válida. Introduce la cantidad del ingreso: ");
                        }
                        Console.Write("Introduce una descripción: ");
                        string descripcionIngreso = Console.ReadLine();
                        cuenta.AddIngreso(cantidadIngreso, descripcionIngreso);
                        Console.WriteLine("Ingreso añadido.");
                        break;

                    case "4":
                        Console.WriteLine("¿Qué gastos quieres ver?");
                        Console.WriteLine("1. Todos");
                        Console.WriteLine("2. Básicos");
                        Console.WriteLine("3. Extras");
                        Console.Write("Selecciona una opción: ");
                        string tipoGasto = Console.ReadLine();
                        if (tipoGasto == "1")
                        {
                            Console.WriteLine("Gastos básicos:");
                            foreach (var g in cuenta.GetGastosBasicos(false))
                                Console.WriteLine(g);
                            Console.WriteLine("Gastos extras:");
                            foreach (var g in cuenta.GetGastosExtras(false))
                                Console.WriteLine(g);
                        }
                        else if (tipoGasto == "2")
                        {
                            Console.WriteLine("Gastos básicos:");
                            foreach (var g in cuenta.GetGastosBasicos(false))
                                Console.WriteLine(g);
                        }
                        else if (tipoGasto == "3")
                        {
                            Console.WriteLine("Gastos extras:");
                            foreach (var g in cuenta.GetGastosExtras(false))
                                Console.WriteLine(g);
                        }
                        else
                        {
                            Console.WriteLine("Opción no válida.");
                        }
                        break;

                    case "5":
                        Console.WriteLine("Ingresos:");
                        foreach (var i in cuenta.GetIngresos(false))
                            Console.WriteLine(i);
                        break;

                    case "6":
                        Console.WriteLine(cuenta.ToString());
                        break;

                    case "7":
                        Console.WriteLine($"Ahorro actual: {cuenta.GetAhorro()}€");
                        break;

                    case "8":
                        Console.WriteLine($"Gastos imprescindibles: {cuenta.GetGastosImprescindibles()}€");
                        break;

                    case "9":
                        var ahora = DateTime.Now;
                        var mesPasado = ahora.AddMonths(-1);
                        var prescindiblesMesPasado = cuenta.GetGastosExtras(false)
                            .Where(g => g.Prescindible && g.Fecha.Month == mesPasado.Month && g.Fecha.Year == mesPasado.Year)
                            .Sum(g => g.Cantidad);
                        Console.WriteLine($"Posibles ahorros del mes pasado (gastos prescindibles): {prescindiblesMesPasado}€");
                        break;

                    case "10":
                        Console.WriteLine("Lista de deseos:");
                        foreach (var p in wishlist.Productos)
                            Console.WriteLine($"{p.Nombre} - {p.Precio}€ - {p.Descripcion}");
                        Console.Write("¿Quieres añadir un producto? (s/n): ");
                        if (Console.ReadLine().Trim().ToLower() == "s")
                        {
                            Console.Write("Nombre: ");
                            string nombreProd = Console.ReadLine();
                            Console.Write("Precio: ");
                            decimal precioProd;
                            while (!decimal.TryParse(Console.ReadLine(), out precioProd))
                            {
                                Console.Write("Precio no válido. Introduce el precio: ");
                            }
                            Console.Write("Descripción: ");
                            string descProd = Console.ReadLine();
                            wishlist.AddProducto(new Producto(nombreProd, precioProd, descProd));
                            Console.WriteLine("Producto añadido a la wishlist.");
                        }
                        break;

                    case "11":
                        Console.WriteLine("Productos que puedes comprar:");
                        foreach (var p in wishlist.GetProductosParaComprar(cuenta))
                            Console.WriteLine($"{p.Nombre} - {p.Precio}€ - {p.Descripcion}");
                        break;

                    case "0":
                        Console.WriteLine("Fin del programa.\nGracias por utilizar la aplicación.");
                        return;

                    default:
                        Console.WriteLine("Opción no válida. Inténtalo de nuevo.");
                        break;
                }
            }
        }
    }
}