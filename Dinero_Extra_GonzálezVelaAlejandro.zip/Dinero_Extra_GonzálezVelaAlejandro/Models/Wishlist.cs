using System.Collections.Generic;
using System.Linq;

namespace IncomeExpenseManager.Models
{
    public class Wishlist
    {
        public Usuario Usuario { get; set; }
        public List<Producto> Productos { get; set; } = new();

        public Wishlist(Usuario usuario)
        {
            Usuario = usuario;
        }

        public void AddProducto(Producto producto)
        {
            Productos.Add(producto);
        }

        public IEnumerable<Producto> GetProductosParaComprar(Cuenta cuenta)
        {
            decimal saldoDisponible = cuenta.Saldo;
            decimal gastosBasicosSiguienteMes = cuenta.GetGastosBasicos(true).Sum(g => g.Cantidad);

            return Productos.Where(p => saldoDisponible - p.Precio >= gastosBasicosSiguienteMes);
        }
    }
}