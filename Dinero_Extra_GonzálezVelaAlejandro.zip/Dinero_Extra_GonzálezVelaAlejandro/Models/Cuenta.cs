using System;
using System.Collections.Generic;
using System.Linq;

namespace IncomeExpenseManager.Models
{
    public class Cuenta
    {
        private Usuario usuario;
        private decimal saldo;
        private List<GastoBasico> gastosBasicos = new();
        private List<GastoExtra> gastosExtras = new();
        private List<Ingreso> ingresos = new();

        public Cuenta(Usuario usuario)
        {
            this.usuario = usuario;
            saldo = 0;
        }

        public void AddGastoBasico(decimal cantidad, string descripcion)
        {
            var gasto = new GastoBasico(cantidad, descripcion, DateTime.Now);
            if (saldo < cantidad)
                throw new InvalidOperationException("Saldo insuficiente para realizar el gasto.");
            saldo -= cantidad;
            gastosBasicos.Add(gasto);
        }

        public void AddGastoExtra(decimal cantidad, string descripcion, bool prescindible)
        {
            var gasto = new GastoExtra(cantidad, descripcion, DateTime.Now, prescindible);
            if (saldo < cantidad)
                throw new InvalidOperationException("Saldo insuficiente para realizar el gasto.");
            saldo -= cantidad;
            gastosExtras.Add(gasto);
        }

        public void AddIngreso(decimal cantidad, string descripcion)
        {
            var ingreso = new Ingreso(cantidad, descripcion, DateTime.Now);
            saldo += cantidad;
            ingresos.Add(ingreso);
        }

        public IEnumerable<GastoBasico> GetGastosBasicos(bool esteMes)
        {
            if (esteMes)
            {
                var ahora = DateTime.Now;
                return gastosBasicos.Where(g => g.Fecha.Month == ahora.Month && g.Fecha.Year == ahora.Year);
            }
            return gastosBasicos;
        }

        public IEnumerable<GastoExtra> GetGastosExtras(bool esteMes)
        {
            if (esteMes)
            {
                var ahora = DateTime.Now;
                return gastosExtras.Where(g => g.Fecha.Month == ahora.Month && g.Fecha.Year == ahora.Year);
            }
            return gastosExtras;
        }

        public IEnumerable<Ingreso> GetIngresos(bool esteMes)
        {
            if (esteMes)
            {
                var ahora = DateTime.Now;
                return ingresos.Where(i => i.Fecha.Month == ahora.Month && i.Fecha.Year == ahora.Year);
            }
            return ingresos;
        }

        public decimal GetAhorro()
        {
            return ingresos.Sum(i => i.Cantidad) - gastosBasicos.Sum(g => g.Cantidad) - gastosExtras.Sum(g => g.Cantidad);
        }

        public decimal GetGastosImprescindibles()
        {
            decimal totalBasicos = gastosBasicos.Sum(g => g.Cantidad);
            decimal totalExtrasNoPrescindibles = gastosExtras.Where(g => !g.Prescindible).Sum(g => g.Cantidad);
            return totalBasicos + totalExtrasNoPrescindibles;
        }

        public decimal Saldo => saldo;

        public override string ToString()
        {
            return $"Usuario: {usuario.Nombre}, Saldo: {saldo}€";
        }
    }
}