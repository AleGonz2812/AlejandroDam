public abstract class Dinero
{
    public decimal Cantidad { get; set; }
    public string Descripcion { get; set; }

    protected Dinero(decimal cantidad, string descripcion)
    {
        Cantidad = cantidad;
        Descripcion = descripcion;
    }

    public abstract override string ToString();
}