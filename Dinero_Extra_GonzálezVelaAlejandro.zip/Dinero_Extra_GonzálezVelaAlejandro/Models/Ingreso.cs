using System;

namespace IncomeExpenseManager.Models
{
    public class Ingreso : Dinero
    {
        public DateTime Fecha { get; set; }

        public Ingreso(decimal cantidad, string descripcion, DateTime fecha)
            : base(cantidad, descripcion)
        {
            Fecha = fecha;
        }

        public override string ToString()
        {
            return $"Ingreso: {Cantidad}€ - {Descripcion} - Fecha: {Fecha:d}";
        }
    }
}