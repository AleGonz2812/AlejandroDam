using System;

namespace IncomeExpenseManager.Models
{
    public class GastoExtra : Gasto
    {
        public DateTime Fecha { get; set; }
        public bool Prescindible { get; set; }

        public GastoExtra(decimal cantidad, string descripcion, DateTime fecha, bool prescindible)
            : base(cantidad, descripcion)
        {
            Fecha = fecha;
            Prescindible = prescindible;
        }

        public override string ToString()
        {
            return $"Gasto Extra: {Cantidad}€ - {Descripcion} - Fecha: {Fecha:d} - Prescindible: {Prescindible}";
        }
    }
}