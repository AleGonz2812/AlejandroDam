using System;

namespace IncomeExpenseManager.Models
{
    public class Gasto : Dinero
    {
        public Gasto(decimal cantidad, string descripcion) : base(cantidad, descripcion)
        {
        }

        public override string ToString()
        {
            return $"Gasto: {Cantidad}€ - {Descripcion}";
        }
    }
}