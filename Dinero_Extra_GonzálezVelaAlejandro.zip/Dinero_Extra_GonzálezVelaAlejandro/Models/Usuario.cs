using System;

namespace IncomeExpenseManager.Models
{
    public class Usuario
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public string Dni { get; private set; }

        public Usuario(string nombre, int edad)
        {
            Nombre = nombre;
            Edad = edad;
            Dni = null;
        }

        public bool SetDni(string dni)
        {
            if (ValidarDni(dni))
            {
                Dni = dni;
                return true;
            }
            return false;
        }

        private bool ValidarDni(string dni)
        {
            return dni.Length == 9 && 
                   int.TryParse(dni.Substring(0, 8), out _) && 
                   char.IsLetter(dni[8]) && 
                   char.IsUpper(dni[8]);
        }

        public override string ToString()
        {
            return $"Nombre: {Nombre}, Edad: {Edad}, DNI: {(Dni != null ? Dni : "No asignado")}";
        }
    }
}