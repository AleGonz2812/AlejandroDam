using System.Text.RegularExpressions;

namespace IncomeExpenseManager.Utils
{
    public static class DniValidator
    {
        public static bool ValidateDni(string dni)
        {
            return dni.Length == 9 && 
                   Regex.IsMatch(dni.Substring(0, 8), @"^\d{8}$") && 
                   char.IsUpper(dni[8]) && 
                   char.IsLetter(dni[8]);
        }
    }
}