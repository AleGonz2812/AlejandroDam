package entorno;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario("Ana");
    }

    @Test
    void getNombre() {
        assertEquals("Ana", usuario.getNombre());
    }

    @Test
    void ingresarSaldo() {
        usuario.ingresarSaldo(200.0);
        assertEquals(200.0, usuario.obtenerSaldo());

        usuario.ingresarSaldo(-50.0); // ingreso inválido, no debe cambiar el saldo
        assertEquals(200.0, usuario.obtenerSaldo());
    }

    @Test
    void registrarGasto_conSaldoSuficiente() {
        usuario.ingresarSaldo(300.0);
        boolean resultado = usuario.registrarGasto(100.0, "Alquiler");
        assertTrue(resultado);
        assertEquals(200.0, usuario.obtenerSaldo());
    }

    @Test
    void registrarGasto_sinSaldoSuficiente() {
        usuario.ingresarSaldo(100.0);
        boolean resultado = usuario.registrarGasto(150.0, "Vacaciones");
        assertFalse(resultado);
        assertEquals(100.0, usuario.obtenerSaldo());
    }

    @Test
    void obtenerSaldo() {
        assertEquals(0.0, usuario.obtenerSaldo());

        usuario.ingresarSaldo(50.0);
        assertEquals(50.0, usuario.obtenerSaldo());
    }
}
