package entorno;

import org.junit.jupiter.api.*;

import java.io.*;

import static org.junit.jupiter.api.Assertions.*;

class MenuTest {

    private final InputStream originalIn = System.in;
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream outContent;

    @BeforeEach
    void setUp() {
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
    }

    @AfterEach
    void restoreStreams() {
        System.setIn(originalIn);
        System.setOut(originalOut);
    }

    @Test
    void testIntroducirUsuario() {
        String input = "Ana\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));

        Menu.main(new String[] {}); // Esto entrará en el bucle, pero puedes comentarlo si prefieres

        // Como Menu.main es un bucle, este test se puede hacer mejor si expones el método introducirUsuario()
        // Por ejemplo, si fuera public static void introducirUsuario(), podríamos llamarlo aquí directamente

        String output = outContent.toString();
        assertTrue(output.contains("Introduce tu nombre de usuario"));
    }

    @Test
    void testFlujoCompleto() {
        String input = String.join("\n",
                "1",        // Introduce nombre de usuario
                "Ana",
                "2",        // Ingresar ingresos
                "500",
                "3",        // Introducir gasto
                "1",        // Vacaciones
                "100",
                "4",        // Mostrar saldo
                "5"         // Salir
        ) + "\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));

        // Ejecutar el programa
        Menu.main(new String[] {});

        String output = outContent.toString();

        // Validaciones básicas
        assertTrue(output.contains("Usuario Ana registrado."));
        assertTrue(output.contains("Ana, su ingreso de 500.0 ha sido registrado."));
        assertTrue(output.contains("Ana, su gasto de 100.0 por Vacaciones ha sido registrado."));
        assertTrue(output.contains("El saldo actual de Ana es: 400.0"));
    }
}
