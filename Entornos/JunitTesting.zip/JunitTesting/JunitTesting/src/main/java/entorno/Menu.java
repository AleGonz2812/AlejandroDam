package entorno;

import java.util.Scanner;

public class Menu {

    private static final Scanner scanner = new Scanner(System.in);
    private static Usuario usuario;

    public static void main(String[] args) {
        boolean salir = false;

        while (!salir) {
            mostrarMenu();
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer de entrada

            switch (opcion) {
                case 1:
                    introducirUsuario();
                    break;
                case 2:
                    introducirIngreso();
                    break;
                case 3:
                    introducirGasto();
                    break;
                case 4:
                    mostrarSaldo();
                    break;
                case 5:
                    salir = true;
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("\nMenú:");
        System.out.println("1. Introduce nombre de usuario");
        System.out.println("2. Introducir ingresos");
        System.out.println("3. Introducir gasto");
        System.out.println("4. Mostrar saldo");
        System.out.println("5. Salir");
    }

    private static void introducirUsuario() {
        System.out.print("Introduce tu nombre de usuario: ");
        String nombre = scanner.nextLine();
        usuario = new Usuario(nombre);
        System.out.println("Usuario " + nombre + " registrado.");
    }

    private static void introducirIngreso() {
        if (usuario == null) {
            System.out.println("Debes introducir tu nombre de usuario primero.");
            return;
        }
        System.out.print(usuario.getNombre() + ", introduce el monto de tus ingresos: ");
        double ingreso = scanner.nextDouble();
        usuario.ingresarSaldo(ingreso);
    }

    private static void introducirGasto() {
        if (usuario == null) {
            System.out.println("Debes introducir tu nombre de usuario primero.");
            return;
        }
        System.out.println(usuario.getNombre() + ", elige un tipo de gasto:");
        System.out.println("1. Vacaciones");
        System.out.println("2. Alquiler");
        System.out.println("3. Vicios variados");
        int tipoGasto = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer de entrada

        String nombreGasto = obtenerTipoGasto(tipoGasto);
        if (nombreGasto != null) {
            System.out.print(usuario.getNombre() + ", introduce el monto de tu gasto en " + nombreGasto + ": ");
            double gasto = scanner.nextDouble();
            usuario.registrarGasto(gasto, nombreGasto);
        } else {
            System.out.println("Opción no válida.");
        }
    }

    private static String obtenerTipoGasto(int opcion) {
        switch (opcion) {
            case 1: return "Vacaciones";
            case 2: return "Alquiler";
            case 3: return "Vicios variados";
            default: return null;
        }
    }

    private static void mostrarSaldo() {
        if (usuario == null) {
            System.out.println("Debes introducir tu nombre de usuario primero.");
            return;
        }
        System.out.println("El saldo actual de " + usuario.getNombre() + " es: " + usuario.obtenerSaldo());
    }
}

