package entorno;

public class Usuario {
    private String nombre;
    private double saldo;

    public Usuario(String nombre) {
        this.nombre = nombre;
        this.saldo = 0.0;
    }

    public String getNombre() {
        return nombre;
    }

    public void ingresarSaldo(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
            System.out.println(nombre + ", su ingreso de " + cantidad + " ha sido registrado.");
        } else {
            System.out.println("El ingreso debe ser mayor a 0.");
        }
    }

    public boolean registrarGasto(double cantidad, String tipoGasto) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
            System.out.println(nombre + ", su gasto de " + cantidad + " por " + tipoGasto + " ha sido registrado.");
            return true;
        } else {
            System.out.println("No tienes suficiente saldo para este gasto.");
            return false;
        }
    }

    public double obtenerSaldo() {
        return saldo;
    }
}
